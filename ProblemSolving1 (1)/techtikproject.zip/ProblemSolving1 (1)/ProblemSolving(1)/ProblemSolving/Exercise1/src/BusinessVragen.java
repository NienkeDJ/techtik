class BusinessVragen {
    String vraag;
    String antwoord;
    String typevraag;
    String optie1;
    String optie2;
    String optie3;
    String optie4;
}
