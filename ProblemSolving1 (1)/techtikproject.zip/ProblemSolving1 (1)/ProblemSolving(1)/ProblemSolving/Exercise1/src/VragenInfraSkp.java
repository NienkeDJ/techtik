class VragenInfraSkip {
    //
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//
        int vraagNummer;

        public VragenInfraSkip() {
        }
    }


